#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

#define STR_MAX 41
#define SONG_MAX 1024
#define YEAR_MAX 5
struct Song{
    char title[STR_MAX];
    char artist[STR_MAX];
    int year_published;
};
struct Song music_library[SONG_MAX];
int current_number_of_songs = 0;

bool crunch_up_from_index(int i){//add
    if (i < 0 || i > current_number_of_songs) {
        printf("Index out of range!\n");
        return false;
    } else if (current_number_of_songs == SONG_MAX){
        printf("Library is full!\n");
        return false;
    }
    current_number_of_songs++;
    for (int j = current_number_of_songs;j>i;j--)
        music_library[j] = music_library[j-1];
    return true;
}

bool crunch_down_from_index(int i){//delete
    if (i < 0 || i > current_number_of_songs) {
        printf("Index out of range!\n");
        return false;
    } else if (current_number_of_songs == 0){
        printf("Library is empty!\n");
        return false;
    }
    current_number_of_songs--;
    for(;i<current_number_of_songs;i++)
        music_library[i] = music_library[i+1];
    return true;
}

// if equal, return add before the index
int find_index_of_song_with_name(char title[STR_MAX]){
    int l = 0, r = current_number_of_songs-1, mid = 0, temp = 0, cmp_l = 0, cmp_r = 0;
    if (r == -1) return 0;
    cmp_l = strcmp(title, music_library[l].title);
    cmp_r = strcmp(title, music_library[r].title);
    if (cmp_l <= 0) {
        return l;
    } else if(cmp_r == 0){
        return r;
    } else if (cmp_r > 0){
        return r+1;
    }
    while (l < r){
        mid = (l+r)/2;
        temp = strcmp(title, music_library[mid].title);
        if (temp == 0) {
            return mid;
        } else if (temp < 0){
            r = mid-1;
        } else{
            l = mid+1;
        }
    }
    return r;
}

bool get_input(char* s,int size){
    if (!fgets(s, sizeof(s)*(size+1), stdin)) return false;
    if (strlen(s) == 0) return false;
    if (s[strlen(s)-1] == '\n')
        s[strlen(s)-1] = '\0';
    return true;
}

void remove_song_from_MusicLibrary_by_name(){
    char *title = (char*)malloc(sizeof(char)*(STR_MAX));
    bool b = true;
    for (size_t i =0; i<STR_MAX; i++){
        title[i] = '\0';
    }
    printf("Title:");
    b = get_input(title, STR_MAX);
    int ind = find_index_of_song_with_name(title);
    if (b&&strcmp(title, music_library[ind].title) == 0){
        crunch_down_from_index(ind);
    } else{
        printf("Title not found!\n");
    }
    free(title);
}

void add_song_to_MusicLibrary(){
    char *title, *artist, *year_published;
    bool b = true;
    title = (char *)malloc(sizeof(char)*(STR_MAX)+1);
    artist = (char *)malloc(sizeof(char)*(STR_MAX)+1);
    year_published = (char *)malloc(sizeof(char)*(YEAR_MAX)+1);
    for (size_t i =0; i<STR_MAX; i++){
        title[i] = '\0';
        artist[i] = '\0';
    }
    for (size_t i = 0; i < YEAR_MAX; i++){
        year_published[i] = '\0';
    }
    int ind = 0;
    if (current_number_of_songs == SONG_MAX){
        printf("Library is full!\n");
        return;
    }
    printf("Title:");
    b &= get_input(title, STR_MAX);
    printf("Artist:");
    b &= get_input(artist, STR_MAX);
    printf("Year Published:");
    b &= get_input(year_published, YEAR_MAX);
    ind = find_index_of_song_with_name(title);
    if (!b||title[0] == '\0' || artist[0] == '\0' || year_published[0] == '\0'||
            strtol(year_published, NULL, 10)==0 ){
        printf("Invalid input!\n");
        free(title);free(artist);free(year_published);
        return;
    }
    crunch_up_from_index(ind);
    strcpy(music_library[ind].title,title);
    strcpy(music_library[ind].artist,artist);
    music_library[ind].year_published = atoi(year_published);
    free(title);free(artist);free(year_published);
}

void look_for_song_by_name(){
    char *title = (char*)malloc(sizeof(char)*STR_MAX+5);
    bool b = true;
    for (size_t i =0; i<STR_MAX; i++){
        title[i] = '\0';
    }
    printf("Title:");
    b = get_input(title, STR_MAX);
    int ind = find_index_of_song_with_name(title);
    if (b && strcmp(title, music_library[ind].title) == 0){
        printf("%d Title:%s, Artist:%s, Year Published:%d\n", ind, music_library[ind].title, music_library[ind].artist,
               music_library[ind].year_published);
    } else{
        printf("Song not found!\n");
    }
    free(title);
}

FILE * open_file(char *file_name, const char * mode){
    FILE * fp = NULL;
    fp = fopen(file_name, mode);
    if (fp == NULL){
        printf("Initial file doesn't exist! Create new.\n");
        return NULL;
    }
    return fp;
}

void store_MusicLibrary(FILE *fp, bool store_or_print){
    for (int i=0;i<current_number_of_songs;i++) {
        if (store_or_print) {
            fprintf(fp, "%s\n%s\n%d\n", music_library[i].title, music_library[i].artist,
                    music_library[i].year_published);
        } else{
            printf("%d Title: %s, Artist: %s, Year Published: %d\n", i,music_library[i].title, music_library[i].artist,
                   music_library[i].year_published);
        }
    }
}

bool get_from_file(FILE* fp, char* s, int size){
    fgets(s, size*sizeof(char)+5, fp);
    if (strlen(s) == 0 || s[0] == '\n') return false;
    if (s[strlen(s)-1] == '\n') 
        s[strlen(s)-1] = '\0';
    return true;
}

void load_MusicLibrary(FILE * fp){
    char *title, *artist, *year_published;
    title = (char *)malloc(sizeof(char)*(STR_MAX)+5);
    artist = (char *)malloc(sizeof(char)*(STR_MAX)+5);
    year_published = (char *)malloc(sizeof(char)*(YEAR_MAX)+5);
    while (!feof(fp)) {
        for (size_t i =0; i< STR_MAX; i++){
            title[i] = '\0';
            artist[i] = '\0';
        }
        for (size_t i = 0; i < YEAR_MAX; i++){
            year_published[i] = '\0';
        }
        while (!feof(fp)) {
            if (get_from_file(fp, title, STR_MAX)) break;
        }
        while (!feof(fp)) {
            if (get_from_file(fp, artist, STR_MAX)) break;
        }
        while (!feof(fp)) {
            if (get_from_file(fp, year_published, YEAR_MAX)) break;
        }
        if (title[0] == '\0' || artist[0] == '\0' || year_published[0] == '\0'){
            break;
        }
        strcpy(music_library[current_number_of_songs].title, title);
        strcpy(music_library[current_number_of_songs].artist, artist);
        music_library[current_number_of_songs++].year_published = atoi(year_published);
        if (current_number_of_songs == SONG_MAX){
            printf("Exceeding largest music library length! Ignore the rest!\n");
            break;
        }
    }
}

void print_MusicLibrary(){
    store_MusicLibrary(NULL, false);
}

void read_song(char *library_name){
    FILE *fp = open_file(library_name, "r");
    if (fp != NULL){
        load_MusicLibrary(fp);
        fclose(fp);
    }
}

void write_song(char * library_name){
    FILE *fp = open_file(library_name, "w");
    if (fp != NULL){
        store_MusicLibrary(fp, true);
        fclose(fp);
    } else {
        printf("Failed to write songs!\n");
        getchar();
    }
}

bool evaluate_command(char c)
{
    while ((getchar()) != '\n');
    switch(c){
        case 'i':
        case 'I':
            add_song_to_MusicLibrary();
            break;
        case 'p':
        case 'P':
            print_MusicLibrary();
            break;
        case 'd':
        case 'D':
            remove_song_from_MusicLibrary_by_name();
            break;
        case 'l':
        case 'L':
            look_for_song_by_name();
            break;
        case 'q':
        case 'Q':
            return false;
        default:
            printf("Wrong command! Please re-enter.\n");
            break;
    }
    return true;
}

void read_command(char * library_name)
{
    char c;
    printf("%s Command:", library_name);
    while((c = getchar())){
        if (!evaluate_command(c)){
            write_song(library_name);
            break;
        }
        printf("%s Command:", library_name);
    }
}

int main(int argc, char** argv)
{
    char library_name[] = "myLibrary";
    switch(argc){
        case 1:
            break;
        case 2:
            strcpy(library_name, argv[1]);
            break;
        default:
            printf("Wrong argument numbers! Going on with default library name!\n");
            break;
    }
    read_song(library_name);
    read_command(library_name);
    return 0;
}
