#ifndef _MY_LS_H
#define _MY_LS_H
const char* dtos(int mon);
void show_stat(char *filename);
void go_into_dir(const char *filename, int indent);
void check_list(int argc, char **argv);
#endif
